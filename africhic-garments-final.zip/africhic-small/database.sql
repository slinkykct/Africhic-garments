-- ═══════════════════════════════════════════════════
--  AFRICHIC GARMENTS — NEON DATABASE SCHEMA
--  Run this entire script in Neon SQL Editor
--  URL: https://console.neon.tech → Your Project → SQL Editor
-- ═══════════════════════════════════════════════════

-- ── USERS ──
CREATE TABLE IF NOT EXISTS users (
  id          SERIAL PRIMARY KEY,
  email       VARCHAR(255) UNIQUE NOT NULL,
  password    VARCHAR(255) NOT NULL,        -- bcrypt hashed
  first_name  VARCHAR(100),
  last_name   VARCHAR(100),
  phone       VARCHAR(30),
  role        VARCHAR(20) DEFAULT 'customer', -- 'customer' | 'admin'
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── CATEGORIES ──
CREATE TABLE IF NOT EXISTS categories (
  id          SERIAL PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  slug        VARCHAR(100) UNIQUE NOT NULL,
  image       VARCHAR(500),
  sort_order  INT DEFAULT 0,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── PRODUCTS ──
CREATE TABLE IF NOT EXISTS products (
  id             SERIAL PRIMARY KEY,
  name           VARCHAR(255) NOT NULL,
  slug           VARCHAR(255) UNIQUE NOT NULL,
  category_id    INT REFERENCES categories(id) ON DELETE SET NULL,
  description    TEXT,
  price          NUMERIC(10,2) NOT NULL,
  original_price NUMERIC(10,2),
  badge          VARCHAR(20),               -- 'new' | 'sale' | ''
  sizes          TEXT[] DEFAULT '{}',       -- ['XS','S','M','L','XL']
  stock          INT DEFAULT 0,
  rating         NUMERIC(3,2) DEFAULT 0,
  review_count   INT DEFAULT 0,
  active         BOOLEAN DEFAULT TRUE,
  created_at     TIMESTAMPTZ DEFAULT NOW(),
  updated_at     TIMESTAMPTZ DEFAULT NOW()
);

-- ── PRODUCT IMAGES ──
CREATE TABLE IF NOT EXISTS product_images (
  id          SERIAL PRIMARY KEY,
  product_id  INT REFERENCES products(id) ON DELETE CASCADE,
  url         VARCHAR(500) NOT NULL,
  sort_order  INT DEFAULT 0,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── HERO SLIDES ──
CREATE TABLE IF NOT EXISTS hero_slides (
  id              SERIAL PRIMARY KEY,
  image           VARCHAR(500) NOT NULL,
  eyebrow         VARCHAR(200),
  title           VARCHAR(200),
  title_em        VARCHAR(200),
  subtitle        TEXT,
  btn_primary_text  VARCHAR(100),
  btn_primary_href  VARCHAR(300),
  btn_secondary_text VARCHAR(100),
  btn_secondary_href VARCHAR(300),
  sort_order      INT DEFAULT 0,
  active          BOOLEAN DEFAULT TRUE,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── ADDRESSES ──
CREATE TABLE IF NOT EXISTS addresses (
  id          SERIAL PRIMARY KEY,
  user_id     INT REFERENCES users(id) ON DELETE CASCADE,
  first_name  VARCHAR(100),
  last_name   VARCHAR(100),
  street      VARCHAR(255),
  city        VARCHAR(100),
  province    VARCHAR(100),
  postal_code VARCHAR(20),
  is_default  BOOLEAN DEFAULT FALSE,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── ORDERS ──
CREATE TABLE IF NOT EXISTS orders (
  id              SERIAL PRIMARY KEY,
  order_number    VARCHAR(20) UNIQUE NOT NULL,
  user_id         INT REFERENCES users(id) ON DELETE SET NULL,
  guest_email     VARCHAR(255),
  status          VARCHAR(30) DEFAULT 'pending', -- pending | processing | shipped | delivered | cancelled
  subtotal        NUMERIC(10,2) NOT NULL,
  delivery_fee    NUMERIC(10,2) DEFAULT 0,
  total           NUMERIC(10,2) NOT NULL,
  delivery_method VARCHAR(50),              -- standard | express | collection
  payment_method  VARCHAR(50),              -- card | eft | paypal | snapscan | zapper
  payment_ref     VARCHAR(255),
  promo_code      VARCHAR(50),
  discount        NUMERIC(10,2) DEFAULT 0,
  notes           TEXT,
  -- Shipping address snapshot
  ship_first_name VARCHAR(100),
  ship_last_name  VARCHAR(100),
  ship_street     VARCHAR(255),
  ship_city       VARCHAR(100),
  ship_province   VARCHAR(100),
  ship_postal     VARCHAR(20),
  ship_phone      VARCHAR(30),
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── ORDER ITEMS ──
CREATE TABLE IF NOT EXISTS order_items (
  id          SERIAL PRIMARY KEY,
  order_id    INT REFERENCES orders(id) ON DELETE CASCADE,
  product_id  INT REFERENCES products(id) ON DELETE SET NULL,
  product_name VARCHAR(255),               -- snapshot at time of order
  product_image VARCHAR(500),
  size        VARCHAR(20),
  price       NUMERIC(10,2) NOT NULL,
  qty         INT NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── NEWSLETTER SUBSCRIBERS ──
CREATE TABLE IF NOT EXISTS subscribers (
  id          SERIAL PRIMARY KEY,
  email       VARCHAR(255) UNIQUE NOT NULL,
  active      BOOLEAN DEFAULT TRUE,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── STORE SETTINGS ──
CREATE TABLE IF NOT EXISTS store_settings (
  key         VARCHAR(100) PRIMARY KEY,
  value       TEXT,
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── PROMO CODES ──
CREATE TABLE IF NOT EXISTS promo_codes (
  id          SERIAL PRIMARY KEY,
  code        VARCHAR(50) UNIQUE NOT NULL,
  type        VARCHAR(20) DEFAULT 'percent', -- 'percent' | 'fixed'
  value       NUMERIC(10,2) NOT NULL,
  min_order   NUMERIC(10,2) DEFAULT 0,
  max_uses    INT,
  uses        INT DEFAULT 0,
  active      BOOLEAN DEFAULT TRUE,
  expires_at  TIMESTAMPTZ,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ═══════════════════════════════════════════════════
--  SEED DATA
-- ═══════════════════════════════════════════════════

-- Categories
INSERT INTO categories (name, slug, image, sort_order) VALUES
  ('All', 'all', '/images/categories/all.jpg', 0),
  ('Women', 'women', '/images/categories/women.jpg', 1),
  ('Men', 'men', '/images/categories/men.jpg', 2),
  ('New Arrivals', 'new-arrivals', '/images/categories/new.jpg', 3),
  ('On Sale', 'sale', '/images/categories/sale.jpg', 4)
ON CONFLICT DO NOTHING;

-- Admin user (password: Africhic@Admin2025)
INSERT INTO users (email, password, first_name, last_name, role) VALUES
  ('admin@africhic.co.za', '$2b$10$rBXJ0bU1NsP5Y2v3yR9iMeQE4K6Tn8FcHjOlVwXdAgZm7pS1qCiue', 'Africhic', 'Admin', 'admin')
ON CONFLICT (email) DO NOTHING;

-- Store settings
INSERT INTO store_settings (key, value) VALUES
  ('store_name', 'Africhic Garments'),
  ('tagline', 'Wear Your Heritage'),
  ('currency', 'R'),
  ('free_shipping_threshold', '850'),
  ('delivery_standard', '80'),
  ('delivery_express', '150'),
  ('phone', '+27 63 561 7298'),
  ('email', 'africhicgarments@gmail.com'),
  ('address', '654 Borzoi Street, Garsfontein Ext 10, Pretoria'),
  ('instagram', 'https://instagram.com/africhicgarments'),
  ('facebook', 'https://facebook.com/africhicgarments'),
  ('announce_bar', 'Free shipping on orders over R850 · New Collection 2025')
ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;

-- Hero slides
INSERT INTO hero_slides (image, eyebrow, title, title_em, subtitle, btn_primary_text, btn_primary_href, btn_secondary_text, btn_secondary_href, sort_order) VALUES
  ('/images/hero/hero-men.jpg', 'Men''s Collection 2025', 'Crafted for', 'Kings', 'Premium dashikis and embroidered shirts celebrating African heritage.', 'Shop Men''s', '/shop.html?cat=Men', 'New Arrivals', '/shop.html?badge=new', 1),
  ('/images/hero/hero-women.jpg', 'Women''s Collection 2025', 'Wear Your', 'Heritage', 'Vibrant African print dresses handcrafted for the bold and beautiful.', 'Shop Women''s', '/shop.html?cat=Women', 'Explore All', '/shop.html', 2),
  ('/images/hero/hero-new.jpg', 'New Arrivals', 'Unapologetically', 'African', 'Fresh prints, authentic patterns, modern silhouettes — just arrived.', 'Shop New In', '/shop.html?badge=new', 'View Sale', '/shop.html?badge=sale', 3)
ON CONFLICT DO NOTHING;

-- Women's products
INSERT INTO products (name, slug, category_id, description, price, original_price, badge, sizes, stock, rating, review_count) VALUES
  ('Yellow Ankara Sundress', 'yellow-ankara-sundress', 2, 'Vibrant yellow and black geometric Ankara print sundress with adjustable spaghetti straps and tiered skirt.', 450.00, NULL, 'new', ARRAY['XS','S','M','L','XL'], 12, 4.8, 24),
  ('Forest Mosaic Fit & Flare', 'forest-mosaic-fit-flare', 2, 'Stunning deep-V neckline fit and flare dress in rich forest green, yellow and orange mosaic print.', 520.00, NULL, 'new', ARRAY['XS','S','M','L','XL'], 8, 5.0, 17),
  ('Monochrome Circles Dress', 'monochrome-circles-dress', 2, 'Bold black and white swirling circle print with gold accents. V-neckline with decorative buttons.', 380.00, 520.00, 'sale', ARRAY['S','M','L','XL'], 5, 4.6, 31),
  ('Red Tribal & Black Ballgown', 'red-tribal-black-ballgown', 2, 'Show-stopping two-tone dress with vibrant red tribal Ankara print bodice and dramatic peplum.', 680.00, 920.00, 'sale', ARRAY['XS','S','M','L'], 3, 4.9, 12),
  ('Navy Botanical Ruffle Dress', 'navy-botanical-ruffle-dress', 2, 'Romantic navy blue dress with delicate red botanical and white dot print. Ruffled off-shoulder neckline.', 490.00, NULL, 'new', ARRAY['XS','S','M','L','XL'], 10, 4.7, 19),
  ('Kaleidoscope Mandala Dress', 'kaleidoscope-mandala-dress', 2, 'Psychedelic multicolour mandala print dress in vivid greens, reds and blues. Scoop neck, sleeveless.', 420.00, 580.00, 'sale', ARRAY['S','M','L','XL','XXL'], 7, 4.5, 28)
ON CONFLICT (slug) DO NOTHING;

-- Men's products
INSERT INTO products (name, slug, category_id, description, price, original_price, badge, sizes, stock, rating, review_count) VALUES
  ('Azure Dashiki — Ornate', 'azure-dashiki-ornate', 3, 'Premium sky blue dashiki shirt with elaborate white and gold embroidered neckpiece.', 390.00, NULL, 'new', ARRAY['S','M','L','XL','XXL'], 15, 4.9, 42),
  ('Navy Dashiki — Minimal', 'navy-dashiki-minimal', 3, 'Understated navy dashiki with clean ivory embroidered neckline detail. Relaxed fit, side slits.', 360.00, NULL, '', ARRAY['S','M','L','XL','XXL','3XL'], 18, 4.7, 35),
  ('Teal Dashiki — Heritage', 'teal-dashiki-heritage', 3, 'Rich teal dashiki with bold geometric embroidered bib panel in black and silver.', 420.00, NULL, 'new', ARRAY['M','L','XL','XXL'], 9, 4.8, 22),
  ('Cream Dashiki — Signature', 'cream-dashiki-signature', 3, 'Warm cream-toned dashiki with bold dark embroidered bib. Geometric cross pattern, stripe border.', 380.00, NULL, 'new', ARRAY['S','M','L','XL','XXL'], 14, 4.6, 18),
  ('Navy Dashiki — Gold Cross', 'navy-dashiki-gold-cross', 3, 'Deep navy dashiki with intricate gold and silver embroidered geometric bib.', 410.00, NULL, '', ARRAY['M','L','XL','XXL','3XL'], 11, 4.9, 29),
  ('Beige Dashiki — Classic', 'beige-dashiki-classic', 3, 'Timeless beige dashiki with dark embroidered bib. Clean cross motif design with stripe framing.', 350.00, 450.00, 'sale', ARRAY['S','M','L','XL'], 6, 4.5, 33),
  ('Grey Dashiki — Embroidered', 'grey-dashiki-embroidered', 3, 'Elegant silver-grey dashiki with delicate gold diamond embroidery running down the neckline.', 370.00, NULL, '', ARRAY['S','M','L','XL','XXL'], 13, 4.7, 21),
  ('Charcoal Dashiki — Bold', 'charcoal-dashiki-bold', 3, 'Dark charcoal grey dashiki with warm gold diamond embroidery along the neckline.', 390.00, NULL, '', ARRAY['M','L','XL','XXL','3XL'], 8, 4.8, 16),
  ('Slate Blue Dashiki — Arrows', 'slate-blue-dashiki-arrows', 3, 'Slate blue dashiki with flowing arrow embroidery motif. Unique asymmetric placement design.', 375.00, NULL, 'new', ARRAY['S','M','L','XL','XXL'], 16, 4.6, 14),
  ('White Dashiki — Arrow', 'white-dashiki-arrow', 3, 'Crisp white dashiki with terracotta arrow embroidery running down the chest.', 340.00, 420.00, 'sale', ARRAY['S','M','L','XL'], 4, 4.4, 27),
  ('Teal Dashiki — Diamonds', 'teal-dashiki-diamonds', 3, 'Vibrant teal dashiki with cascading diamond motif embroidery. Three-button chest placket.', 400.00, NULL, 'new', ARRAY['M','L','XL','XXL'], 10, 4.9, 38),
  ('Navy Dashiki — Diamonds', 'navy-dashiki-diamonds', 3, 'Rich navy blue dashiki with cascading terracotta diamond motif embroidery.', 400.00, NULL, '', ARRAY['S','M','L','XL','XXL','3XL'], 12, 4.7, 31),
  ('White Dashiki — Cross', 'white-dashiki-cross', 3, 'Pure white dashiki with terracotta geometric cross embroidery. Three buttons and chest pocket.', 355.00, NULL, '', ARRAY['S','M','L','XL','XXL'], 20, 4.6, 24)
ON CONFLICT (slug) DO NOTHING;

-- Product images (linked to products by position/name)
-- Women's dresses
INSERT INTO product_images (product_id, url, sort_order)
SELECT p.id, '/images/products/dress-yellow-ankara.jpg', 0 FROM products p WHERE p.slug = 'yellow-ankara-sundress' ON CONFLICT DO NOTHING;
INSERT INTO product_images (product_id, url, sort_order)
SELECT p.id, '/images/products/dress-green-floral.jpg', 0 FROM products p WHERE p.slug = 'forest-mosaic-fit-flare' ON CONFLICT DO NOTHING;
INSERT INTO product_images (product_id, url, sort_order)
SELECT p.id, '/images/products/dress-green-mosaic.jpg', 1 FROM products p WHERE p.slug = 'forest-mosaic-fit-flare' ON CONFLICT DO NOTHING;
INSERT INTO product_images (product_id, url, sort_order)
SELECT p.id, '/images/products/dress-black-circles.jpg', 0 FROM products p WHERE p.slug = 'monochrome-circles-dress' ON CONFLICT DO NOTHING;
INSERT INTO product_images (product_id, url, sort_order)
SELECT p.id, '/images/products/dress-red-black.jpg', 0 FROM products p WHERE p.slug = 'red-tribal-black-ballgown' ON CONFLICT DO NOTHING;
INSERT INTO product_images (product_id, url, sort_order)
SELECT p.id, '/images/products/dress-navy-floral.jpg', 0 FROM products p WHERE p.slug = 'navy-botanical-ruffle-dress' ON CONFLICT DO NOTHING;
INSERT INTO product_images (product_id, url, sort_order)
SELECT p.id, '/images/products/dress-multicolor-mandala.jpg', 0 FROM products p WHERE p.slug = 'kaleidoscope-mandala-dress' ON CONFLICT DO NOTHING;
-- Men's dashikis
INSERT INTO product_images (product_id, url, sort_order)
SELECT p.id, '/images/products/dashiki-blue-ornate.jpg', 0 FROM products p WHERE p.slug = 'azure-dashiki-ornate' ON CONFLICT DO NOTHING;
INSERT INTO product_images (product_id, url, sort_order)
SELECT p.id, '/images/products/dashiki-navy-minimal.jpg', 0 FROM products p WHERE p.slug = 'navy-dashiki-minimal' ON CONFLICT DO NOTHING;
INSERT INTO product_images (product_id, url, sort_order)
SELECT p.id, '/images/products/dashiki-teal-geometric.jpg', 0 FROM products p WHERE p.slug = 'teal-dashiki-heritage' ON CONFLICT DO NOTHING;
INSERT INTO product_images (product_id, url, sort_order)
SELECT p.id, '/images/products/dashiki-cream-cross.jpg', 0 FROM products p WHERE p.slug = 'cream-dashiki-signature' ON CONFLICT DO NOTHING;
INSERT INTO product_images (product_id, url, sort_order)
SELECT p.id, '/images/products/dashiki-navy-cross.jpg', 0 FROM products p WHERE p.slug = 'navy-dashiki-gold-cross' ON CONFLICT DO NOTHING;
INSERT INTO product_images (product_id, url, sort_order)
SELECT p.id, '/images/products/dashiki-beige-cross.jpg', 0 FROM products p WHERE p.slug = 'beige-dashiki-classic' ON CONFLICT DO NOTHING;
INSERT INTO product_images (product_id, url, sort_order)
SELECT p.id, '/images/products/dashiki-grey-embroidered.jpg', 0 FROM products p WHERE p.slug = 'grey-dashiki-embroidered' ON CONFLICT DO NOTHING;
INSERT INTO product_images (product_id, url, sort_order)
SELECT p.id, '/images/products/dashiki-charcoal-embroidered.jpg', 0 FROM products p WHERE p.slug = 'charcoal-dashiki-bold' ON CONFLICT DO NOTHING;
INSERT INTO product_images (product_id, url, sort_order)
SELECT p.id, '/images/products/dashiki-slate-blue.jpg', 0 FROM products p WHERE p.slug = 'slate-blue-dashiki-arrows' ON CONFLICT DO NOTHING;
INSERT INTO product_images (product_id, url, sort_order)
SELECT p.id, '/images/products/dashiki-white-arrow.jpg', 0 FROM products p WHERE p.slug = 'white-dashiki-arrow' ON CONFLICT DO NOTHING;
INSERT INTO product_images (product_id, url, sort_order)
SELECT p.id, '/images/products/dashiki-teal-diamond.jpg', 0 FROM products p WHERE p.slug = 'teal-dashiki-diamonds' ON CONFLICT DO NOTHING;
INSERT INTO product_images (product_id, url, sort_order)
SELECT p.id, '/images/products/dashiki-navy-diamond.jpg', 0 FROM products p WHERE p.slug = 'navy-dashiki-diamonds' ON CONFLICT DO NOTHING;
INSERT INTO product_images (product_id, url, sort_order)
SELECT p.id, '/images/products/dashiki-white-cross.jpg', 0 FROM products p WHERE p.slug = 'white-dashiki-cross' ON CONFLICT DO NOTHING;

-- Promo code example
INSERT INTO promo_codes (code, type, value, min_order) VALUES
  ('WELCOME10', 'percent', 10, 0),
  ('AFRICHIC20', 'percent', 20, 500)
ON CONFLICT (code) DO NOTHING;

-- ═══════════════════════════════════════════════════
--  VERIFY — run these to confirm setup
-- ═══════════════════════════════════════════════════
-- SELECT COUNT(*) FROM products;        -- should be 19
-- SELECT COUNT(*) FROM product_images;  -- should be 20
-- SELECT COUNT(*) FROM hero_slides;     -- should be 3
-- SELECT * FROM users WHERE role='admin';
