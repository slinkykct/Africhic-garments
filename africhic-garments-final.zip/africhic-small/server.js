// ── AFRICHIC GARMENTS — API SERVER ──
// Node.js + Express + Neon PostgreSQL
// Deploy to Railway / Render / Fly.io

require('dotenv').config();
const express    = require('express');
const cors       = require('cors');
const bcrypt     = require('bcryptjs');
const jwt        = require('jsonwebtoken');
const { Pool }   = require('pg');
const multer     = require('multer');
const path       = require('path');
const fs         = require('fs');

const app  = express();
const PORT = process.env.PORT || 3001;

// ── DATABASE ──
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});

pool.query('SELECT NOW()').then(() => console.log('✅ Neon DB connected'))
  .catch(e => console.error('❌ DB error:', e.message));

// ── MIDDLEWARE ──
const allowedOrigins = (process.env.FRONTEND_URL || '*').split(',');
app.use(cors({
  origin: (origin, cb) => {
    if (!origin || allowedOrigins.includes('*') || allowedOrigins.includes(origin)) cb(null, true);
    else cb(new Error('CORS blocked: ' + origin));
  },
  credentials: true
}));
app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));

// ── FILE UPLOAD (multer — base64 fallback for serverless) ──
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_, f, cb) => {
    /\.(jpg|jpeg|png|webp)$/i.test(f.originalname) ? cb(null, true) : cb(new Error('Images only'));
  }
});

// ── AUTH HELPERS ──
const JWT_SECRET = process.env.JWT_SECRET || 'africhic_secret_change_in_production';

function signToken(user) {
  return jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
}

function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'No token' });
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({ error: 'Invalid token' }); }
}

function adminMiddleware(req, res, next) {
  authMiddleware(req, res, () => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admins only' });
    next();
  });
}

function genOrderNumber() {
  return 'AF-' + Date.now().toString(36).toUpperCase().slice(-6);
}

// ═══════════════════════════════════════════════════
//  PUBLIC ROUTES
// ═══════════════════════════════════════════════════

// ── HEALTH ──
app.get('/api/health', (_, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

// ── STORE SETTINGS (public) ──
app.get('/api/settings', async (_, res) => {
  try {
    const { rows } = await pool.query('SELECT key, value FROM store_settings');
    const obj = {};
    rows.forEach(r => obj[r.key] = r.value);
    res.json(obj);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── HERO SLIDES ──
app.get('/api/hero', async (_, res) => {
  try {
    const { rows } = await pool.query(
      'SELECT * FROM hero_slides WHERE active=true ORDER BY sort_order ASC'
    );
    res.json(rows);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── CATEGORIES ──
app.get('/api/categories', async (_, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM categories ORDER BY sort_order ASC');
    res.json(rows);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── PRODUCTS ──
app.get('/api/products', async (req, res) => {
  try {
    const { cat, badge, search, sort, limit = 100, offset = 0 } = req.query;
    let where = ['p.active = true'];
    let params = [];
    let i = 1;

    if (cat && cat !== 'all') {
      where.push(`c.slug = $${i++}`);
      params.push(cat);
    }
    if (badge) {
      where.push(`p.badge = $${i++}`);
      params.push(badge);
    }
    if (search) {
      where.push(`(p.name ILIKE $${i} OR p.description ILIKE $${i})`);
      params.push(`%${search}%`);
      i++;
    }

    const orderMap = {
      'price_asc': 'p.price ASC',
      'price_desc': 'p.price DESC',
      'name_asc': 'p.name ASC',
      'rating': 'p.rating DESC',
      'newest': 'p.created_at DESC'
    };
    const orderBy = orderMap[sort] || 'p.created_at DESC';

    const q = `
      SELECT p.*,
             c.name AS category_name, c.slug AS category_slug,
             COALESCE(
               json_agg(pi.url ORDER BY pi.sort_order) FILTER (WHERE pi.url IS NOT NULL),
               '[]'
             ) AS images
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      LEFT JOIN product_images pi ON pi.product_id = p.id
      WHERE ${where.join(' AND ')}
      GROUP BY p.id, c.name, c.slug
      ORDER BY ${orderBy}
      LIMIT $${i} OFFSET $${i+1}
    `;
    params.push(limit, offset);

    const { rows } = await pool.query(q, params);
    res.json(rows);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── SINGLE PRODUCT ──
app.get('/api/products/:slug', async (req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT p.*,
             c.name AS category_name, c.slug AS category_slug,
             COALESCE(
               json_agg(pi.url ORDER BY pi.sort_order) FILTER (WHERE pi.url IS NOT NULL),
               '[]'
             ) AS images
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      LEFT JOIN product_images pi ON pi.product_id = p.id
      WHERE p.slug = $1 AND p.active = true
      GROUP BY p.id, c.name, c.slug
    `, [req.params.slug]);

    if (!rows.length) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── AUTH ──
app.post('/api/auth/register', async (req, res) => {
  try {
    const { email, password, firstName, lastName, phone } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    const hash = await bcrypt.hash(password, 10);
    const { rows } = await pool.query(
      'INSERT INTO users (email, password, first_name, last_name, phone) VALUES ($1,$2,$3,$4,$5) RETURNING id,email,first_name,last_name,role',
      [email.toLowerCase(), hash, firstName, lastName, phone]
    );
    res.json({ token: signToken(rows[0]), user: rows[0] });
  } catch(e) {
    if (e.code === '23505') return res.status(400).json({ error: 'Email already registered' });
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const { rows } = await pool.query(
      'SELECT * FROM users WHERE email = $1', [email?.toLowerCase()]
    );
    if (!rows.length) return res.status(401).json({ error: 'Invalid credentials' });
    const ok = await bcrypt.compare(password, rows[0].password);
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
    const { password: _, ...user } = rows[0];
    res.json({ token: signToken(user), user });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/auth/me', authMiddleware, async (req, res) => {
  try {
    const { rows } = await pool.query(
      'SELECT id,email,first_name,last_name,phone,role FROM users WHERE id=$1', [req.user.id]
    );
    res.json(rows[0]);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── ORDERS (create) ──
app.post('/api/orders', async (req, res) => {
  const client = await pool.connect();
  try {
    const { items, shipping, deliveryMethod, deliveryFee, paymentMethod, promoCode, discount, guestEmail } = req.body;
    if (!items?.length) return res.status(400).json({ error: 'No items' });

    await client.query('BEGIN');

    const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0);
    const total    = subtotal + (deliveryFee || 0) - (discount || 0);
    const orderNum = genOrderNumber();
    const userId   = req.headers.authorization ? (jwt.decode(req.headers.authorization.replace('Bearer ',''))?.id || null) : null;

    const { rows: [order] } = await client.query(`
      INSERT INTO orders (order_number, user_id, guest_email, status, subtotal, delivery_fee, total,
        delivery_method, payment_method, promo_code, discount,
        ship_first_name, ship_last_name, ship_street, ship_city, ship_province, ship_postal, ship_phone)
      VALUES ($1,$2,$3,'pending',$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)
      RETURNING *
    `, [orderNum, userId, guestEmail, subtotal, deliveryFee||0, total,
        deliveryMethod, paymentMethod, promoCode, discount||0,
        shipping.firstName, shipping.lastName, shipping.street, shipping.city, shipping.province, shipping.postal, shipping.phone]);

    for (const item of items) {
      await client.query(`
        INSERT INTO order_items (order_id, product_id, product_name, product_image, size, price, qty)
        VALUES ($1,$2,$3,$4,$5,$6,$7)
      `, [order.id, item.productId, item.name, item.image, item.size, item.price, item.qty]);

      await client.query(
        'UPDATE products SET stock = GREATEST(0, stock - $1) WHERE id = $2',
        [item.qty, item.productId]
      );
    }

    await client.query('COMMIT');
    res.json({ orderNumber: orderNum, orderId: order.id });
  } catch(e) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: e.message });
  } finally { client.release(); }
});

// ── ORDER TRACKING ──
app.get('/api/orders/:orderNumber', async (req, res) => {
  try {
    const { rows: [order] } = await pool.query(
      'SELECT * FROM orders WHERE order_number=$1', [req.params.orderNumber]
    );
    if (!order) return res.status(404).json({ error: 'Order not found' });
    const { rows: items } = await pool.query(
      'SELECT * FROM order_items WHERE order_id=$1', [order.id]
    );
    res.json({ ...order, items });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── USER ORDERS ──
app.get('/api/my/orders', authMiddleware, async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT o.*, json_agg(oi.*) AS items FROM orders o
       LEFT JOIN order_items oi ON oi.order_id = o.id
       WHERE o.user_id=$1 GROUP BY o.id ORDER BY o.created_at DESC`,
      [req.user.id]
    );
    res.json(rows);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── PROMO CODE VALIDATE ──
app.post('/api/promo/validate', async (req, res) => {
  try {
    const { code, total } = req.body;
    const { rows: [promo] } = await pool.query(
      'SELECT * FROM promo_codes WHERE code=UPPER($1) AND active=true', [code]
    );
    if (!promo) return res.status(400).json({ error: 'Invalid promo code' });
    if (promo.expires_at && new Date(promo.expires_at) < new Date())
      return res.status(400).json({ error: 'Promo code expired' });
    if (promo.max_uses && promo.uses >= promo.max_uses)
      return res.status(400).json({ error: 'Promo code exhausted' });
    if (total < promo.min_order)
      return res.status(400).json({ error: `Min order R${promo.min_order} required` });

    const discount = promo.type === 'percent'
      ? (total * promo.value / 100)
      : Math.min(promo.value, total);

    res.json({ valid: true, discount: Number(discount.toFixed(2)), type: promo.type, value: promo.value });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── NEWSLETTER ──
app.post('/api/newsletter', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email required' });
    await pool.query(
      'INSERT INTO subscribers (email) VALUES ($1) ON CONFLICT (email) DO UPDATE SET active=true',
      [email.toLowerCase()]
    );
    res.json({ success: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ═══════════════════════════════════════════════════
//  ADMIN ROUTES
// ═══════════════════════════════════════════════════

// ── DASHBOARD STATS ──
app.get('/api/admin/stats', adminMiddleware, async (_, res) => {
  try {
    const [orders, revenue, customers, products, pending, lowStock] = await Promise.all([
      pool.query('SELECT COUNT(*) FROM orders'),
      pool.query("SELECT COALESCE(SUM(total),0) FROM orders WHERE status != 'cancelled'"),
      pool.query("SELECT COUNT(*) FROM users WHERE role='customer'"),
      pool.query('SELECT COUNT(*) FROM products WHERE active=true'),
      pool.query("SELECT COUNT(*) FROM orders WHERE status='pending'"),
      pool.query("SELECT COUNT(*) FROM products WHERE stock <= 5 AND active=true")
    ]);
    res.json({
      totalOrders:    parseInt(orders.rows[0].count),
      revenue:        parseFloat(revenue.rows[0].coalesce),
      customers:      parseInt(customers.rows[0].count),
      products:       parseInt(products.rows[0].count),
      pendingOrders:  parseInt(pending.rows[0].count),
      lowStockCount:  parseInt(lowStock.rows[0].count)
    });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── ADMIN ORDERS ──
app.get('/api/admin/orders', adminMiddleware, async (req, res) => {
  try {
    const { status, limit=50, offset=0 } = req.query;
    let where = status ? 'WHERE o.status=$1' : '';
    let params = status ? [status, limit, offset] : [limit, offset];
    const li = status ? 2 : 1;
    const { rows } = await pool.query(`
      SELECT o.*, 
        COALESCE(u.first_name||' '||u.last_name, o.guest_email, 'Guest') AS customer_name,
        json_agg(json_build_object('name',oi.product_name,'qty',oi.qty,'price',oi.price,'image',oi.product_image,'size',oi.size)) AS items
      FROM orders o
      LEFT JOIN users u ON u.id=o.user_id
      LEFT JOIN order_items oi ON oi.order_id=o.id
      ${where}
      GROUP BY o.id, u.first_name, u.last_name
      ORDER BY o.created_at DESC
      LIMIT $${li} OFFSET $${li+1}
    `, params);
    res.json(rows);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.patch('/api/admin/orders/:id/status', adminMiddleware, async (req, res) => {
  try {
    const { status } = req.body;
    const valid = ['pending','processing','shipped','delivered','cancelled'];
    if (!valid.includes(status)) return res.status(400).json({ error: 'Invalid status' });
    await pool.query(
      'UPDATE orders SET status=$1, updated_at=NOW() WHERE id=$2', [status, req.params.id]
    );
    res.json({ success: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── ADMIN PRODUCTS ──
app.get('/api/admin/products', adminMiddleware, async (_, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT p.*, c.name AS category_name,
        COALESCE(json_agg(pi.url ORDER BY pi.sort_order) FILTER (WHERE pi.url IS NOT NULL),'[]') AS images
      FROM products p
      LEFT JOIN categories c ON c.id=p.category_id
      LEFT JOIN product_images pi ON pi.product_id=p.id
      GROUP BY p.id, c.name
      ORDER BY p.created_at DESC
    `);
    res.json(rows);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/admin/products', adminMiddleware, async (req, res) => {
  const client = await pool.connect();
  try {
    const { name, categoryId, description, price, originalPrice, badge, sizes, stock, images } = req.body;
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')
               + '-' + Date.now().toString(36);
    await client.query('BEGIN');
    const { rows: [p] } = await client.query(`
      INSERT INTO products (name, slug, category_id, description, price, original_price, badge, sizes, stock)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *
    `, [name, slug, categoryId, description, price, originalPrice||null, badge||'', sizes||[], stock||0]);

    if (images?.length) {
      for (let i=0; i<images.length; i++) {
        await client.query('INSERT INTO product_images (product_id, url, sort_order) VALUES ($1,$2,$3)',
          [p.id, images[i], i]);
      }
    }
    await client.query('COMMIT');
    res.json(p);
  } catch(e) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: e.message });
  } finally { client.release(); }
});

app.put('/api/admin/products/:id', adminMiddleware, async (req, res) => {
  const client = await pool.connect();
  try {
    const { name, categoryId, description, price, originalPrice, badge, sizes, stock, active, images } = req.body;
    await client.query('BEGIN');
    await client.query(`
      UPDATE products SET
        name=$1, category_id=$2, description=$3, price=$4, original_price=$5,
        badge=$6, sizes=$7, stock=$8, active=$9, updated_at=NOW()
      WHERE id=$10
    `, [name, categoryId, description, price, originalPrice||null, badge||'', sizes||[], stock, active!==false, req.params.id]);

    if (images !== undefined) {
      await client.query('DELETE FROM product_images WHERE product_id=$1', [req.params.id]);
      for (let i=0; i<images.length; i++) {
        await client.query('INSERT INTO product_images (product_id, url, sort_order) VALUES ($1,$2,$3)',
          [req.params.id, images[i], i]);
      }
    }
    await client.query('COMMIT');
    res.json({ success: true });
  } catch(e) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: e.message });
  } finally { client.release(); }
});

app.delete('/api/admin/products/:id', adminMiddleware, async (req, res) => {
  try {
    await pool.query('UPDATE products SET active=false WHERE id=$1', [req.params.id]);
    res.json({ success: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── ADMIN IMAGE UPLOAD (base64 → saves to /images/products/) ──
app.post('/api/admin/upload', adminMiddleware, async (req, res) => {
  try {
    const { base64, filename } = req.body;
    if (!base64 || !filename) return res.status(400).json({ error: 'base64 and filename required' });
    
    const match = base64.match(/^data:image\/(\w+);base64,/);
    if (!match) return res.status(400).json({ error: 'Invalid base64 image' });
    
    const ext  = match[1];
    const safe = filename.replace(/[^a-z0-9\-_\.]/gi,'_').toLowerCase();
    const name = safe.endsWith('.'+ext) ? safe : safe+'.'+ext;
    const dir  = path.join('/tmp', 'images');
    
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    
    const buf = Buffer.from(base64.replace(/^data:image\/\w+;base64,/,''), 'base64');
    fs.writeFileSync(path.join(dir, name), buf);
    
    res.json({ url: `/images/products/${name}` });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── ADMIN HERO SLIDES ──
app.get('/api/admin/hero', adminMiddleware, async (_, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM hero_slides ORDER BY sort_order ASC');
    res.json(rows);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/admin/hero', adminMiddleware, async (req, res) => {
  try {
    const { image, eyebrow, title, titleEm, subtitle, btnPrimaryText, btnPrimaryHref, btnSecondaryText, btnSecondaryHref, sortOrder } = req.body;
    const { rows: [s] } = await pool.query(`
      INSERT INTO hero_slides (image, eyebrow, title, title_em, subtitle, btn_primary_text, btn_primary_href, btn_secondary_text, btn_secondary_href, sort_order)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *
    `, [image, eyebrow, title, titleEm, subtitle, btnPrimaryText, btnPrimaryHref, btnSecondaryText, btnSecondaryHref, sortOrder||0]);
    res.json(s);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/admin/hero/:id', adminMiddleware, async (req, res) => {
  try {
    const { image, eyebrow, title, titleEm, subtitle, btnPrimaryText, btnPrimaryHref, btnSecondaryText, btnSecondaryHref, sortOrder, active } = req.body;
    await pool.query(`
      UPDATE hero_slides SET image=$1, eyebrow=$2, title=$3, title_em=$4, subtitle=$5,
        btn_primary_text=$6, btn_primary_href=$7, btn_secondary_text=$8, btn_secondary_href=$9,
        sort_order=$10, active=$11 WHERE id=$12
    `, [image, eyebrow, title, titleEm, subtitle, btnPrimaryText, btnPrimaryHref, btnSecondaryText, btnSecondaryHref, sortOrder, active!==false, req.params.id]);
    res.json({ success: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/admin/hero/:id', adminMiddleware, async (req, res) => {
  try {
    await pool.query('DELETE FROM hero_slides WHERE id=$1', [req.params.id]);
    res.json({ success: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── ADMIN SETTINGS ──
app.get('/api/admin/settings', adminMiddleware, async (_, res) => {
  try {
    const { rows } = await pool.query('SELECT key, value FROM store_settings ORDER BY key');
    const obj = {};
    rows.forEach(r => obj[r.key] = r.value);
    res.json(obj);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/admin/settings', adminMiddleware, async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    for (const [key, value] of Object.entries(req.body)) {
      await client.query(
        'INSERT INTO store_settings (key,value,updated_at) VALUES ($1,$2,NOW()) ON CONFLICT (key) DO UPDATE SET value=$2, updated_at=NOW()',
        [key, String(value)]
      );
    }
    await client.query('COMMIT');
    res.json({ success: true });
  } catch(e) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: e.message });
  } finally { client.release(); }
});

// ── ADMIN CUSTOMERS ──
app.get('/api/admin/customers', adminMiddleware, async (_, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT u.id, u.email, u.first_name, u.last_name, u.phone, u.created_at,
        COUNT(o.id) AS order_count,
        COALESCE(SUM(o.total),0) AS total_spent
      FROM users u
      LEFT JOIN orders o ON o.user_id=u.id
      WHERE u.role='customer'
      GROUP BY u.id ORDER BY u.created_at DESC
    `);
    res.json(rows);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── ADMIN SUBSCRIBERS ──
app.get('/api/admin/subscribers', adminMiddleware, async (_, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM subscribers ORDER BY created_at DESC');
    res.json(rows);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── ADMIN PROMO CODES ──
app.get('/api/admin/promos', adminMiddleware, async (_, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM promo_codes ORDER BY created_at DESC');
    res.json(rows);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/admin/promos', adminMiddleware, async (req, res) => {
  try {
    const { code, type, value, minOrder, maxUses, expiresAt } = req.body;
    const { rows: [p] } = await pool.query(
      'INSERT INTO promo_codes (code,type,value,min_order,max_uses,expires_at) VALUES (UPPER($1),$2,$3,$4,$5,$6) RETURNING *',
      [code, type, value, minOrder||0, maxUses||null, expiresAt||null]
    );
    res.json(p);
  } catch(e) {
    if (e.code==='23505') return res.status(400).json({ error: 'Code already exists' });
    res.status(500).json({ error: e.message });
  }
});

app.patch('/api/admin/promos/:id', adminMiddleware, async (req, res) => {
  try {
    await pool.query('UPDATE promo_codes SET active=$1 WHERE id=$2', [req.body.active, req.params.id]);
    res.json({ success: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});


// ── FIRST-RUN SETUP ──
// POST /api/setup with { "secret": "africhic-setup-2025", "password": "your-password" }
// Call this ONCE after deploy to hash and store the admin password
app.post('/api/setup', async (req, res) => {
  try {
    const { secret, password } = req.body;
    if (secret !== (process.env.SETUP_SECRET || 'africhic-setup-2025')) {
      return res.status(403).json({ error: 'Invalid setup secret' });
    }
    const hash = await bcrypt.hash(password || 'Africhic@Admin2025', 10);
    await pool.query(
      'UPDATE users SET password=$1 WHERE email=$2',
      [hash, 'admin@africhic.co.za']
    );
    res.json({ success: true, message: 'Admin password updated. You can now login.' });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── START ──
app.listen(PORT, () => console.log(`🚀 Africhic API running on :${PORT}`));
module.exports = app;
