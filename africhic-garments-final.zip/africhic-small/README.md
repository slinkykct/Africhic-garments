# Africhic Garments — Deployment Guide

## 🗄️ STEP 1: Set Up Neon Database

1. Go to **https://console.neon.tech**
2. Open your project → click **SQL Editor**
3. Paste the entire contents of **`database.sql`** and click **Run**
4. Verify: `SELECT COUNT(*) FROM products;` should return **19**

---

## 🚀 STEP 2: Deploy Backend to Railway

1. Go to **https://railway.app** → New Project → Deploy from GitHub repo
   *(or use the Railway CLI: `railway login && railway init && railway up`)*

2. Set these **Environment Variables** in Railway dashboard:
   ```
   DATABASE_URL = postgresql://neondb_owner:npg_LBRtbYdAo4l1@ep-orange-meadow-ak876j8q-pooler.c-3.us-west-2.aws.neon.tech/neondb?sslmode=require&channel_binding=require
   JWT_SECRET   = africhic_super_secret_jwt_key_2025_change_me
   PORT         = 3001
   FRONTEND_URL = https://YOUR-NETLIFY-URL.netlify.app
   ```

3. After deploy, copy your Railway URL — it will look like:
   `https://africhic-api-production.up.railway.app`

---

## 🌐 STEP 3: Update Frontend API URL

Open `public/js/api.js` and replace this line:
```js
: 'https://YOUR-RAILWAY-URL.up.railway.app/api';
```
with your actual Railway URL.

---

## 📡 STEP 4: Deploy Frontend to Netlify

1. Go to **https://netlify.com** → Add New Site → Deploy manually
2. Drag & drop the **`public/`** folder
3. Your site is live! 🎉

---

## 🔐 Admin Login

- URL: `https://your-site.netlify.app/admin.html`
- Email: `admin@africhic.co.za`
- Password: `Africhic@Admin2025`

**Change your password immediately after first login** (via Neon SQL Editor):
```sql
-- Generate a new bcrypt hash at https://bcrypt-generator.com (rounds: 10)
UPDATE users SET password = 'YOUR_NEW_HASH' WHERE email = 'admin@africhic.co.za';
```

---

## 🖼️ Admin Features (Live on Main Site)

| Feature | Effect |
|---------|--------|
| **Products** → Add/Edit/Remove | Products appear/disappear on shop.html immediately |
| **Hero Slides** → Add/Edit/Delete | Slideshow on homepage updates live |
| **Orders** → Change Status | Customer sees updated status on account.html |
| **Store Settings** → Save | Announcement bar, contact details update live |
| **Promo Codes** → Create/Toggle | Active codes work at checkout instantly |
| **Upload Images** | Upload product & hero images — stored in /images/ |

---

## 📁 File Structure

```
africhic/
├── public/                 ← Deploy this to Netlify
│   ├── index.html          ← Homepage
│   ├── shop.html           ← Shop / catalogue
│   ├── product.html        ← Product detail
│   ├── checkout.html       ← Checkout + payment
│   ├── account.html        ← Customer account
│   ├── admin.html          ← Admin panel
│   ├── css/main.css        ← All styles
│   ├── js/
│   │   ├── api.js          ← API client + Auth + Settings
│   │   └── main.js         ← Cart, Hero, shared utilities
│   └── images/
│       ├── products/       ← All product images
│       └── hero/           ← Hero slideshow images
├── api/server.js           ← Deploy this to Railway
├── package.json
├── .env                    ← Backend env vars (never commit!)
├── database.sql            ← Run once in Neon SQL Editor
└── netlify.toml            ← Netlify config
```

---

## 🛒 Payment Setup

The checkout currently records orders with payment method. To process real payments:
- **Card**: Integrate Peach Payments (SA) or Stripe
- **SnapScan/Zapper**: Add your merchant QR codes to checkout.html
- **PayPal**: Add PayPal SDK button in checkout.html
- **EFT**: Update bank details in checkout.html

Contact: africhicgarments@gmail.com | +27 63 561 7298
