// ── AFRICHIC API CONFIG ──
// After deploying your backend to Railway/Render, update API_BASE below

const API_BASE = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
  ? 'http://localhost:3001/api'
  : 'https://YOUR-RAILWAY-URL.up.railway.app/api'; // ← UPDATE AFTER BACKEND DEPLOY

// ── API CLIENT ──
const API = {
  token() { return localStorage.getItem('africhic_token'); },

  headers(extra = {}) {
    const h = { 'Content-Type': 'application/json', ...extra };
    if (API.token()) h['Authorization'] = 'Bearer ' + API.token();
    return h;
  },

  async get(path) {
    const r = await fetch(API_BASE + path, { headers: API.headers() });
    if (!r.ok) throw await r.json();
    return r.json();
  },

  async post(path, body) {
    const r = await fetch(API_BASE + path, {
      method: 'POST',
      headers: API.headers(),
      body: JSON.stringify(body)
    });
    if (!r.ok) throw await r.json();
    return r.json();
  },

  async put(path, body) {
    const r = await fetch(API_BASE + path, {
      method: 'PUT',
      headers: API.headers(),
      body: JSON.stringify(body)
    });
    if (!r.ok) throw await r.json();
    return r.json();
  },

  async patch(path, body) {
    const r = await fetch(API_BASE + path, {
      method: 'PATCH',
      headers: API.headers(),
      body: JSON.stringify(body)
    });
    if (!r.ok) throw await r.json();
    return r.json();
  },

  async del(path) {
    const r = await fetch(API_BASE + path, { method: 'DELETE', headers: API.headers() });
    if (!r.ok) throw await r.json();
    return r.json();
  }
};

// Auth helpers
const Auth = {
  user() {
    try { return JSON.parse(localStorage.getItem('africhic_user') || 'null'); } catch { return null; }
  },
  isAdmin() { return Auth.user()?.role === 'admin'; },
  isLoggedIn() { return !!API.token(); },
  logout() {
    localStorage.removeItem('africhic_token');
    localStorage.removeItem('africhic_user');
    window.location.href = '/index.html';
  },
  async login(email, password) {
    const data = await API.post('/auth/login', { email, password });
    localStorage.setItem('africhic_token', data.token);
    localStorage.setItem('africhic_user', JSON.stringify(data.user));
    return data.user;
  },
  async register(payload) {
    const data = await API.post('/auth/register', payload);
    localStorage.setItem('africhic_token', data.token);
    localStorage.setItem('africhic_user', JSON.stringify(data.user));
    return data.user;
  }
};

// Store settings cache
const Settings = {
  _data: null,
  async load() {
    if (Settings._data) return Settings._data;
    try {
      Settings._data = await API.get('/settings');
      Settings.applyToDOM();
    } catch { /* use defaults */ }
    return Settings._data;
  },
  get(key, fallback = '') {
    return Settings._data?.[key] ?? fallback;
  },
  applyToDOM() {
    const bar = document.getElementById('announceBar');
    if (bar && Settings._data?.announce_bar) bar.textContent = Settings._data.announce_bar;
  }
};
