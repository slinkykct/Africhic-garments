// ── AFRICHIC GARMENTS — PRODUCT DATABASE ──
// All images stored in /images/products/
// Manage products, prices, hero & settings via Admin panel

const PRODUCTS = [
  // ── WOMEN'S ──
  { id:1, name:"Yellow Ankara Sundress", category:"Women", price:450, orig:null,
    desc:"Vibrant yellow & black geometric Ankara print sundress. Adjustable spaghetti straps, tiered skirt, authentic wax print selvedge border at hem. Light and airy for warm weather.",
    images:["/images/products/dress-yellow-ankara.jpg"], badge:"new", sizes:["XS","S","M","L","XL"], stock:12, rating:4.8, reviews:24 },
  { id:2, name:"Forest Mosaic Fit & Flare", category:"Women", price:520, orig:null,
    desc:"Rich forest green, yellow & orange mosaic print. Deep-V neckline, cap sleeves, fitted bodice with full swirling skirt. A statement piece for any occasion.",
    images:["/images/products/dress-green-floral.jpg","/images/products/dress-green-mosaic.jpg"], badge:"new", sizes:["XS","S","M","L","XL"], stock:8, rating:5.0, reviews:17 },
  { id:3, name:"Monochrome Circles Dress", category:"Women", price:380, orig:520,
    desc:"Bold black & white swirling circle print with gold accents. V-neckline with decorative buttons, drop waist with full pleated skirt. Sophisticated and artistic.",
    images:["/images/products/dress-black-circles.jpg"], badge:"sale", sizes:["S","M","L","XL"], stock:5, rating:4.6, reviews:31 },
  { id:4, name:"Red Tribal & Black Ballgown", category:"Women", price:680, orig:920,
    desc:"Show-stopping two-tone dress. Vibrant red tribal Ankara print bodice with dramatic peplum, fluid black taffeta skirt. Cap sleeves, back zip. Perfect for celebrations.",
    images:["/images/products/dress-red-black.jpg"], badge:"sale", sizes:["XS","S","M","L"], stock:3, rating:4.9, reviews:12 },
  { id:5, name:"Navy Botanical Ruffle Dress", category:"Women", price:490, orig:null,
    desc:"Romantic navy blue with delicate red botanical & white dot print. Off-shoulder ruffled neckline, tiered ruffle skirt. Light and feminine for summer events.",
    images:["/images/products/dress-navy-floral.jpg"], badge:"new", sizes:["XS","S","M","L","XL"], stock:10, rating:4.7, reviews:19 },
  { id:6, name:"Kaleidoscope Mandala Dress", category:"Women", price:420, orig:580,
    desc:"Psychedelic multicolour mandala print in vivid greens, reds and blues. Scoop neck, sleeveless with flared skirt and mesh hem trim. A walking piece of art.",
    images:["/images/products/dress-multicolor-mandala.jpg"], badge:"sale", sizes:["S","M","L","XL","XXL"], stock:7, rating:4.5, reviews:28 },

  // ── MEN'S ──
  { id:7, name:"Azure Dashiki — Ornate", category:"Men", price:390, orig:null,
    desc:"Sky blue with elaborate white & gold embroidered neckpiece. Round neck with decorative button, white contrast cuffs. Classic African elegance for formal occasions.",
    images:["/images/products/dashiki-blue-ornate.jpg"], badge:"new", sizes:["S","M","L","XL","XXL"], stock:15, rating:4.9, reviews:42 },
  { id:8, name:"Navy Dashiki — Minimal", category:"Men", price:360, orig:null,
    desc:"Understated navy with clean ivory embroidered neckline. Relaxed fit, side slits, short sleeves. The perfect blend of traditional craft and modern simplicity.",
    images:["/images/products/dashiki-navy-minimal.jpg"], badge:"", sizes:["S","M","L","XL","XXL","3XL"], stock:18, rating:4.7, reviews:35 },
  { id:9, name:"Teal Dashiki — Heritage", category:"Men", price:420, orig:null,
    desc:"Rich teal with bold geometric embroidered bib panel in black & silver. Traditional cross and diamond motifs. Button-up neckline, relaxed silhouette.",
    images:["/images/products/dashiki-teal-geometric.jpg"], badge:"new", sizes:["M","L","XL","XXL"], stock:9, rating:4.8, reviews:22 },
  { id:10, name:"Cream Dashiki — Signature", category:"Men", price:380, orig:null,
    desc:"Warm cream with bold dark embroidered bib. Geometric cross pattern, stripe border. Smart-casual piece transitioning seamlessly from day to evening.",
    images:["/images/products/dashiki-cream-cross.jpg"], badge:"new", sizes:["S","M","L","XL","XXL"], stock:14, rating:4.6, reviews:18 },
  { id:11, name:"Navy Dashiki — Gold Cross", category:"Men", price:410, orig:null,
    desc:"Deep navy with intricate gold & silver embroidered geometric bib. Traditional cross and diamond motifs with stripe border detail. Premium craftsmanship.",
    images:["/images/products/dashiki-navy-cross.jpg"], badge:"", sizes:["M","L","XL","XXL","3XL"], stock:11, rating:4.9, reviews:29 },
  { id:12, name:"Beige Dashiki — Classic", category:"Men", price:350, orig:450,
    desc:"Timeless beige with dark embroidered bib. Clean cross motif with stripe framing. Versatile colour for any occasion from casual to semi-formal.",
    images:["/images/products/dashiki-beige-cross.jpg"], badge:"sale", sizes:["S","M","L","XL"], stock:6, rating:4.5, reviews:33 },
  { id:13, name:"Grey Dashiki — Embroidered", category:"Men", price:370, orig:null,
    desc:"Silver-grey with delicate gold diamond embroidery running down the neckline. Minimalist design with pocket detail. Sophisticated and refined.",
    images:["/images/products/dashiki-grey-embroidered.jpg"], badge:"", sizes:["S","M","L","XL","XXL"], stock:13, rating:4.7, reviews:21 },
  { id:14, name:"Charcoal Dashiki — Bold", category:"Men", price:390, orig:null,
    desc:"Dark charcoal grey with warm gold diamond embroidery. Strong masculine silhouette with subtle decorative detailing. A modern African staple.",
    images:["/images/products/dashiki-charcoal-embroidered.jpg"], badge:"", sizes:["M","L","XL","XXL","3XL"], stock:8, rating:4.8, reviews:16 },
  { id:15, name:"Slate Blue Dashiki — Arrows", category:"Men", price:375, orig:null,
    desc:"Slate blue with flowing arrow embroidery motif. Unique asymmetric placement, black buttons, chest pocket. Contemporary take on the traditional dashiki form.",
    images:["/images/products/dashiki-slate-blue.jpg"], badge:"new", sizes:["S","M","L","XL","XXL"], stock:16, rating:4.6, reviews:14 },
  { id:16, name:"White Dashiki — Arrow", category:"Men", price:340, orig:420,
    desc:"Crisp white with terracotta arrow embroidery. Clean and contemporary, perfect for warm days or layering. Lightweight cotton fabric.",
    images:["/images/products/dashiki-white-arrow.jpg"], badge:"sale", sizes:["S","M","L","XL"], stock:4, rating:4.4, reviews:27 },
  { id:17, name:"Teal Dashiki — Diamonds", category:"Men", price:400, orig:null,
    desc:"Vibrant teal with cascading diamond motif embroidery. Three-button chest placket, flowing silhouette. The diamond pattern symbolises prosperity.",
    images:["/images/products/dashiki-teal-diamond.jpg"], badge:"new", sizes:["M","L","XL","XXL"], stock:10, rating:4.9, reviews:38 },
  { id:18, name:"Navy Dashiki — Diamonds", category:"Men", price:400, orig:null,
    desc:"Rich navy blue with cascading terracotta diamond motif. Three-button placket, relaxed silhouette with side slits. Premium cotton for all-day comfort.",
    images:["/images/products/dashiki-navy-diamond.jpg"], badge:"", sizes:["S","M","L","XL","XXL","3XL"], stock:12, rating:4.7, reviews:31 },
  { id:19, name:"White Dashiki — Cross", category:"Men", price:355, orig:null,
    desc:"Pure white with terracotta geometric cross embroidery. Three buttons and chest pocket. Pairs beautifully with tailored trousers or chinos.",
    images:["/images/products/dashiki-white-cross.jpg"], badge:"", sizes:["S","M","L","XL","XXL"], stock:20, rating:4.6, reviews:24 }
];

// Hero slides — fully manageable via Admin > Hero Slides
let HERO_SLIDES = JSON.parse(localStorage.getItem('africhic_hero') || 'null') || [
  { id:1, image:"/images/hero/hero-men.jpg",   eyebrow:"Men's Collection 2025", title:"Crafted for", em:"Kings",    sub:"Premium dashikis and embroidered shirts celebrating African heritage.", btn1:"Shop Men's", href1:"shop.html?cat=Men",   btn2:"New Arrivals", href2:"shop.html?badge=new" },
  { id:2, image:"/images/hero/hero-women.jpg", eyebrow:"Women's Collection 2025",title:"Wear Your", em:"Heritage", sub:"Vibrant African print dresses handcrafted for the bold and beautiful.",  btn1:"Shop Women's",href1:"shop.html?cat=Women", btn2:"Explore All",  href2:"shop.html" },
  { id:3, image:"/images/hero/hero-new.jpg",   eyebrow:"New Arrivals",           title:"Unapologetically",em:"African",sub:"Fresh prints, authentic patterns, modern silhouettes — just arrived.", btn1:"Shop New In", href1:"shop.html?badge=new", btn2:"View Sale",   href2:"shop.html?badge=sale" }
];

// Store settings — manageable via Admin > Settings
let STORE_SETTINGS = JSON.parse(localStorage.getItem('africhic_settings') || 'null') || {
  name:"Africhic Garments", tagline:"Wear Your Heritage",
  currency:"R", freeShipping:850, deliveryStd:80, deliveryExp:150,
  phone:"+27 63 561 7298", email:"africhicgarments@gmail.com",
  address:"654 Borzoi Street, Garsfontein Ext 10, Pretoria",
  instagram:"https://instagram.com/africhicgarments",
  facebook:"https://facebook.com/africhicgarments",
  tiktok:"https://tiktok.com/@africhicgarments"
};
