// ── AFRICHIC GARMENTS — MAIN.JS ──

const Cart = {
  get(){ try{return JSON.parse(localStorage.getItem('africhic_cart')||'[]')}catch{return[]} },
  save(c){ localStorage.setItem('africhic_cart',JSON.stringify(c)); Cart.updateUI(); },
  add(id,size,qty=1){
    const p=PRODUCTS.find(x=>x.id===id); if(!p)return;
    const cart=Cart.get(), key=`${id}-${size}`, ex=cart.find(i=>i.key===key);
    if(ex) ex.qty=Math.min(ex.qty+qty,10);
    else cart.push({key,id,name:p.name,price:p.price,image:p.images[0],size,qty});
    Cart.save(cart);
    Toast.show(p.name+' added to cart','ok');
  },
  remove(key){ Cart.save(Cart.get().filter(i=>i.key!==key)); },
  changeQty(key,d){
    const c=Cart.get(), it=c.find(i=>i.key===key);
    if(it) it.qty=Math.max(1,Math.min(10,it.qty+d));
    Cart.save(c);
  },
  total(){ return Cart.get().reduce((s,i)=>s+i.price*i.qty,0); },
  count(){ return Cart.get().reduce((s,i)=>s+i.qty,0); },
  clear(){ localStorage.removeItem('africhic_cart'); Cart.updateUI(); },
  updateUI(){
    const n=Cart.count();
    document.querySelectorAll('.cart-n').forEach(el=>el.textContent=n);
    Cart.renderDrawer();
  },
  renderDrawer(){
    const clist=document.getElementById('clist');
    const cfoot=document.getElementById('cfoot');
    if(!clist) return;
    const cart=Cart.get();
    if(!cart.length){
      clist.innerHTML=`<div class="cempty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg><p>Your cart is empty</p><small>Add some beautiful pieces!</small></div>`;
      if(cfoot) cfoot.style.display='none'; return;
    }
    clist.innerHTML=cart.map(i=>`
      <div class="ci">
        <img class="ci-img" src="${i.image}" alt="${i.name}"/>
        <div class="ci-detail">
          <div class="ci-nm">${i.name}</div>
          <div class="ci-var">Size ${i.size}</div>
          <div class="ci-bottom">
            <div class="qrow">
              <button class="qb" onclick="Cart.changeQty('${i.key}',-1)">−</button>
              <span>${i.qty}</span>
              <button class="qb" onclick="Cart.changeQty('${i.key}',1)">+</button>
            </div>
            <div class="ci-price">R${(i.price*i.qty).toFixed(2)}</div>
          </div>
          <span class="ci-del" onclick="Cart.remove('${i.key}')">Remove</span>
        </div>
      </div>`).join('');
    if(cfoot){
      cfoot.style.display='block';
      const sub=document.getElementById('cSubtot');
      if(sub) sub.textContent=`R${Cart.total().toFixed(2)}`;
    }
  }
};

const Toast = {
  show(msg,type=''){
    let t=document.getElementById('toast');
    if(!t){t=document.createElement('div');t.id='toast';document.body.appendChild(t);}
    t.textContent=msg; t.className=`toast ${type} up`;
    clearTimeout(t._t); t._t=setTimeout(()=>t.classList.remove('up'),3000);
  }
};

function openCart(){ document.getElementById('cartDrawer')?.classList.add('open'); document.getElementById('dov')?.classList.add('on'); document.body.style.overflow='hidden'; }
function closeCart(){ document.getElementById('cartDrawer')?.classList.remove('open'); document.getElementById('dov')?.classList.remove('on'); document.body.style.overflow=''; }
function openAuth(){ document.getElementById('authMov')?.classList.add('on'); }
function closeAuth(){ document.getElementById('authMov')?.classList.remove('on'); }
function switchMTab(tab,btn){ document.querySelectorAll('.mtab').forEach(t=>t.classList.remove('on')); btn.classList.add('on'); document.getElementById('mtLogin').style.display=tab==='login'?'':'none'; document.getElementById('mtReg').style.display=tab==='register'?'':'none'; }
function mockLogin(){ localStorage.setItem('africhic_user',JSON.stringify({name:'Guest',email:'guest@africhic.co.za'})); closeAuth(); Toast.show('Welcome to Africhic! ✦','ok'); setTimeout(()=>window.location.reload(),700); }
function subNL(){ const el=document.getElementById('nlEmail'); if(!el?.value){Toast.show('Please enter your email');return;} Toast.show('Subscribed — welcome! ✦','ok'); el.value=''; }

function quickAdd(id){
  const p=PRODUCTS.find(x=>x.id===id); if(!p) return;
  Cart.add(id,p.sizes[Math.floor(p.sizes.length/2)],1);
  openCart();
}

function renderProductCard(p){
  const disc=p.orig?Math.round((1-p.price/p.orig)*100):0;
  return `<div class="pcard" onclick="window.location.href='product.html?id=${p.id}'">
    <div class="pimg">
      <img src="${p.images[0]}" alt="${p.name}" loading="lazy"/>
      ${p.badge?`<span class="pbadge b-${p.badge}">${p.badge==='new'?'New':'Sale'}</span>`:''}
      <div class="phov">
        <button class="pact" onclick="event.stopPropagation();quickAdd(${p.id})" title="Add to cart">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
        </button>
      </div>
      <div class="pquick"><button onclick="event.stopPropagation();quickAdd(${p.id})">Quick Add</button></div>
    </div>
    <div class="pbody">
      <div class="pcat">${p.category}</div>
      <div class="pname">${p.name}</div>
      <div class="pprices">
        <span class="p-now">R${p.price.toFixed(2)}</span>
        ${p.orig?`<span class="p-was">R${p.orig.toFixed(2)}</span><span class="p-off">-${disc}%</span>`:''}
      </div>
      <div class="pstars">${'★'.repeat(Math.floor(p.rating))} <span>(${p.reviews})</span></div>
    </div>
  </div>`;
}

function initHero(){
  const track=document.getElementById('heroTrack');
  const dotsEl=document.getElementById('hDots');
  if(!track||!HERO_SLIDES?.length) return;
  let idx=0; const count=HERO_SLIDES.length;
  track.innerHTML=HERO_SLIDES.map(s=>`<div class="hero-slide" style="background-image:url('${s.image}')"></div>`).join('');
  if(dotsEl) dotsEl.innerHTML=HERO_SLIDES.map((_,i)=>`<button class="h-dot${i===0?' on':''}" onclick="goSlide(${i})"></button>`).join('');
  function updateText(s){
    const set=(id,v)=>{const el=document.getElementById(id);if(el)el.innerHTML=v;};
    set('heroEyebrow',s.eyebrow); set('heroTitle',`${s.title}<br><em>${s.em}</em>`); set('heroSub',s.sub);
    const b1=document.getElementById('heroBtnPrimary'), b2=document.getElementById('heroBtnSecondary');
    if(b1){b1.textContent=s.btn1;b1.href=s.href1;} if(b2){b2.textContent=s.btn2;b2.href=s.href2;}
  }
  window.goSlide=function(n){ idx=(n+count)%count; track.style.transform=`translateX(-${idx*100}%)`; document.querySelectorAll('.h-dot').forEach((d,i)=>d.classList.toggle('on',i===idx)); updateText(HERO_SLIDES[idx]); };
  document.getElementById('hPrev')?.addEventListener('click',()=>{goSlide(idx-1);resetT();});
  document.getElementById('hNext')?.addEventListener('click',()=>{goSlide(idx+1);resetT();});
  let timer=setInterval(()=>goSlide(idx+1),5000);
  function resetT(){clearInterval(timer);timer=setInterval(()=>goSlide(idx+1),5000);}
  updateText(HERO_SLIDES[0]);
}

document.addEventListener('DOMContentLoaded',()=>{
  Cart.updateUI();
  initHero();
  document.getElementById('dov')?.addEventListener('click',closeCart);
  document.getElementById('authMov')?.addEventListener('click',e=>{if(e.target===document.getElementById('authMov'))closeAuth();});
});
